<nav>
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="characters.php">Characters</a></li>
		<li><a href="weapons.php">Weapons</a></li>
		<li><a href="abilities.php">Abilities</a></li>
		<li><a href="items.php">Items</a></li>
		<li><a href="passive_ability.php">Passive Abilities</a></li>
		<li><a href="ult_ability.php">Ultimate Abilities</a></li>
		<li><a href="locations.php">Locations</a></li>
		<li>
			<div class="update-profile">
				<form action="update.php" method="post">
					<button type ="submit" name="update-submit">Update Profile</button>
				</form>
			</div>
		</li>
		<li>
			<div class="logout-button">
				<form action="includes/logout.inc.php" method="post">
					<button type ="submit" name="logout-submit">Logout</button>
				</form>
			</div>
		</li>
	</ul>
</nav>
