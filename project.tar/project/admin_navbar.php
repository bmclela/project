<nav>
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="insert_items.php">Insert Items</a></li>
		<li><a href="delete_items.php">Delete Items</a></li>
		<li><a href="update_items.php">Update Items</a></li>
		<li><a href="manage_users.php">Manage Users</a></li>
		<li>
			<div class="logout-button">
				<form action="includes/logout.inc.php" method="post">
					<button type ="submit" name="logout-submit">Logout</button>
				</form>
			</div>
		</li>
	</ul>
</nav>
