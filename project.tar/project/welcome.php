<h1 class="title1">Welcome to the Overwatch Item Repository</h1>
<h2 class="title2">Log in as:</h2>
<br>

<div class="indent">
	<ul>
		<li>
			<form action="user_login.php" method="post">
				<button type ="submit" name="user-login">User</button>
			</form>
		</li>
		<li>
			<form action="admin_login.php" method="post">
				<button type ="submit" name="admin-login">Admin</button>
			</form>
		</li>
	</ul>
</div>
